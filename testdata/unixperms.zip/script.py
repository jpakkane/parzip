#!/usr/bin/env python3

print('I am a script. That you can run.')
